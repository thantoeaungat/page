@echo OFF
title Vivo Fastboot Model Checker (Qualcomm & MTK)
cd /d %~dp0

echo ========================================================
echo       VIVO FASTBOOT MODEL & INFO CHECKER
echo       Supports: Qualcomm & MediaTek (MTK)
echo ========================================================
echo.

echo [*] Checking connection status...
fastboot devices
echo.

echo [1] General Product & Model Variables:
fastboot getvar product
fastboot getvar model
fastboot getvar board
fastboot getvar unlocked
echo.

echo [2] OEM Device & Security Info (Mostly Qualcomm):
fastboot oem device-info
fastboot oem device-name
echo.

echo [3] Baseband & Version Details:
fastboot getvar version-baseband
fastboot getvar secure
echo.

echo ========================================================
echo [SUCCESS] Check completed! If variables show values above, 
echo your device is successfully connected in Fastboot mode.
echo ========================================================
pause